export class LeaseOption {}
