// src/app.module.ts
import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { AuthModule } from './auth/auth.module';
import { ShuttleServicesModule } from './shuttle-services/shuttle-services.module';
import { FleetManagementModule } from './fleet-management/fleet-management.module';
import { CareerJobsModule } from './career-jobs/career-jobs.module';
import { AdminModule } from './admin/admin.module';
// import { RoundTripModule } from './round-trip/round-trip.module';
import { OneWayModule } from './one-way/one-way.module';
import { TripModule } from './shuttle-trip/trip.module';
import { CarRentalsModule } from './car-rentals/car-rentals.module';
import { GuestBookingModule } from './guest-booking/guest-booking.module';
import { MoServicesModule } from './mo-services/mo-services.module';
import { PaymentsModule } from './payments/payments.module';
import { TripsModule } from './trips/trips.module';
import { PaystackBookingsModule } from './paystack-bookings/paystack-bookings.module';
import { BookingModule } from './booking/booking.module';
import { ContactUsModule } from './contact-us/contact-us.module';
import { ShuttleBookingModule } from './shuttle-booking/shuttle-booking.module';
import { PricingModule } from './pricing/pricing.module';
import { MapsModule } from './maps/maps.module';
import { NotificationsModule } from './notifications/notifications.module';
// import { AuditService } from './audit/audit.service';
import { AuditModule } from './audit/audit.module';
import { ScheduleModule } from './schedule/schedule.module';
import { MailModule } from './mail/mail.module';
import { VerificationServicesModule } from './verification-services/verification-services.module';
import { OdSchoolModule } from './od-school/od-school.module';
import { ThrottlerModule } from '@nestjs/throttler';
import { JobApplicationsModule } from './job-application/job-application.module';
import { HealthModule } from './health/health.module';
import { ChatModule } from './chat/chat.module';
import { CityModule } from './city/city.module';
import { CloudinaryModule } from './common/cloudinary/cloudinary.module';
import { CarModule } from './cars/cars.module';
import { FleetvehicleModule } from './fleetvehicle/fleetvehicle.module';
import { BookingRequestModule } from './booking-request/booking-request.module';
// import { TypeOrmModule } from '@nestjs/typeorm';
import { SubscriptionModule } from './subscription/subscription.module';
import { NewsletterModule } from './newsletter/newsletter.module';
import { SmsModule } from './notifications/sms/sms.module';
import { AirportTransferModule } from './airport-transfer/airport-transfer.module';
import { LeaseOptionsModule } from './lease-options/lease-options.module';
import { CustomQuoteModule } from './custom-quote/custom-quote.module';
import { NewsroomModule } from './newsroom/newsroom.module';

@Module({
  imports: [
    ThrottlerModule.forRoot({
      throttlers: [
        {
          ttl: 60000, // 1 minute
          limit: 5, // max 5 requests
        },
      ],
    }),
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),

    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => {
        const url = configService.get<string>('MONGO_URL');
        const fallbackUrl = 'mongodb://localhost:27017/booking';

        if (url) {
          console.log('✅ Connecting to MongoDB...');
        } else {
          console.log('⚠️ Using fallback MongoDB URL');
        }

        return {
          uri: url || fallbackUrl,
        };
      },
      inject: [ConfigService],
    }),

    AuthModule,
    BookingModule,
    ShuttleServicesModule,
    FleetManagementModule,
    CareerJobsModule,
    AdminModule,
    // RoundTripModule,
    OneWayModule,
    TripModule,
    CarRentalsModule,
    GuestBookingModule,
    MoServicesModule,
    PaymentsModule,
    TripsModule,
    PaystackBookingsModule,
    ContactUsModule,
    ShuttleBookingModule,
    PricingModule,
    MapsModule,
    NotificationsModule,
    AuditModule,
    ScheduleModule,
    MailModule,
    VerificationServicesModule,
    OdSchoolModule,
    JobApplicationsModule,
    HealthModule,
    ChatModule,
    CityModule,
    CloudinaryModule,
    CarModule,
    FleetvehicleModule,
    BookingRequestModule,
    SubscriptionModule,
    NewsletterModule,
    SmsModule,
    AirportTransferModule,
    LeaseOptionsModule,
    CustomQuoteModule,
    NewsroomModule, // Newsroom articles — public fetch, admin create/edit/delete
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}
