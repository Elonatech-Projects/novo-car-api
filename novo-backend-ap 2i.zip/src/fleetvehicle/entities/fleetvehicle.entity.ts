export class Fleetvehicle {}
