export class CreateFleetvehicleDto {}
